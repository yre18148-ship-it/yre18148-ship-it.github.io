import Arrow from "./Arrow.jsx";
import { useEffect, useState } from "react";
import Hero from "./Hero.jsx";
import CaseStudy from "./CaseStudy.jsx";
import { cases } from "./cases.js";

const projects = [
  ["warm", "01 / HEALTHCARE", "KineSense", "Pro", "智能运动康复设备", "/assets/portfolio/p07-01.webp", "KineSense Pro 康复设备"],
  ["blue", "02 / HOME APPLIANCE", "ZenBrew", "Hub", "智能茶吧机", "/assets/portfolio/p12-01.webp", "ZenBrew Hub 智能茶吧机"],
  ["orange", "03 / PERSONAL COMFORT", "Halo", "Breeze", "挂脖式风扇", "/assets/portfolio/p17-02.webp", "HaloBreeze 挂脖式风扇的爆炸图"],
  ["deep", "04 / ECOLOGICAL SYSTEM", "AQUA", "Sentinel", "海域哨卫概念设计", "/assets/cases/aqua-main.jpg", "AQUA Sentinel 海域哨卫概念设计"],
];

const software = [
  ["Blender", "3D 建模与渲染", "icons8-blender-3d-250.png"],
  ["KeyShot", "产品材质与渲染", "keyshot.png"],
  ["CorelDRAW", "矢量绘图与排版", "coreldraw.png"],
  ["Rhino", "产品曲面建模", "icons8-rhinoceros-6-250.png"],
  ["Figma", "界面与交互设计", "icons8-figma-240.png"],
  ["Adobe", "视觉创意工具", "icons8-adobe-240.png"],
  ["Photoshop", "图像处理与表达", "icons8-adobe-photoshop-240.png"],
];

const creativeTools = [
  ["ChatGPT", "思路梳理与创意探索", "chatgpt.png"],
  ["Gemini", "多模态分析与灵感拓展", "gemini-ai.png"],
  ["摄影", "构图、光影与影像表达", "camera.png"],
];

const skills = [
  ["Research", "User insight, opportunity mapping, scenario definition."],
  ["Product", "Concept design, industrial form, CMF and system thinking."],
  ["Visualization", "Rhino, Blender, KeyShot, CorelDRAW, Photoshop, Figma and photography."],
  ["AI Workflow", "ChatGPT and Gemini for research, ideation and creative workflows."],
];

export default function App() {
  const [route, setRoute] = useState(() => window.location.hash);
  const slug = route.startsWith('#/work/') ? route.split('/')[2] : null;
  const project = cases.find(item => item.slug === slug);
  useEffect(() => {
    const update = () => setRoute(window.location.hash);
    window.addEventListener('hashchange', update);
    return () => window.removeEventListener('hashchange', update);
  }, []);
  useEffect(() => {
    if (!project) document.title = 'Chen Wenjing | Industrial Designer';
    const timer = window.setTimeout(() => {
      const target = project ? route.split('/')[3] : route.slice(1);
      if (target) document.getElementById(target)?.scrollIntoView({ behavior:'instant' });
      else window.scrollTo({ top:0, behavior:'instant' });
    }, 0);
    return () => window.clearTimeout(timer);
  }, [route, project]);
  useEffect(() => {
    const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const onScroll = () => {
      document.getElementById("nav")?.classList.toggle("nav-scrolled", window.scrollY > 40);
      if (!reduceMotion) {
        document.querySelectorAll(".parallax").forEach((image) => {
          const rect = image.parentElement.getBoundingClientRect();
          const offset = Math.max(-22, Math.min(22, (window.innerHeight / 2 - (rect.top + rect.height / 2)) * 0.035));
          image.style.transform = `scale(1.09) translateY(${offset}px)`;
        });
      }
    };
    const timer = window.setTimeout(() => document.body.classList.remove("is-loading"), reduceMotion ? 0 : 180);
    const observer = new IntersectionObserver((entries) => entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("is-in");
        observer.unobserve(entry.target);
      }
    }), { threshold: 0.16 });
    const scenes = document.querySelectorAll("[data-scene]");
    const cards = document.querySelectorAll(".reveal-card");
    scenes.forEach((scene) => observer.observe(scene));
    cards.forEach((card, index) => card.style.setProperty("--delay", `${(index % 4) * 105}ms`));
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => {
      window.clearTimeout(timer);
      observer.disconnect();
      window.removeEventListener("scroll", onScroll);
    };
  }, [slug]);

  const scrollTo = (id) => document.getElementById(id)?.scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth" });

  if (project) return <CaseStudy project={project} />;
  return <>
    <div className="opening" aria-hidden="true"><span>CHEN WENJING</span><div /><b>PORTFOLIO 2026</b></div>
    <header className="nav" id="nav">
      <button className="wordmark" onClick={() => scrollTo("home")}>CW<span>.</span></button>
      <nav aria-label="主导航"><button onClick={() => scrollTo("about")}>ABOUT</button><button onClick={() => scrollTo("work")}>WORK</button><button onClick={() => scrollTo("skills")}>EXPERTISE</button></nav>
      <button className="nav-contact" onClick={() => scrollTo("contact")}>LET'S TALK <span className="arrow-icon nav-arrow" aria-hidden="true" /></button>
    </header>
    <main>
      <Hero />
      <section className="about section" id="about" data-scene>
        <div className="section-top"><p className="kicker"><span>01</span> INTRODUCTION</p><p className="section-note">Product designer.<br />Currently based in Guilin, China.</p></div>
        <div className="about-layout"><h2 className="scene-title"><span>Thinking in</span><span>form, feeling</span><span>in use.</span></h2><div className="portrait-wrap media-reveal"><img className="parallax" src="/assets/portrait.jpg" alt="陈文静的个人肖像" /></div><div className="about-text"><p>我是一名产品设计师，关注用户体验、产品形态与真实场景之间的连接。通过调研、概念、建模与可视化，将复杂问题转化为清晰而有温度的产品。</p><div className="education-note"><span>EDUCATION / 2023—2027</span><strong>桂林电子科技大学</strong><p>艺术与设计学院 · 产品设计</p></div><a href="mailto:427818148@qq.com">MORE ABOUT ME <span className="arrow-icon about-arrow" aria-hidden="true" /></a></div></div>
        <div className="software-panel"><div className="software-heading"><p className="kicker">MY TOOLKIT</p><h3>让想法成为可见的设计。</h3></div><div className="software-grid">{software.map(([name, detail, icon]) => <div className="software-item" key={name}><img src={`/assets/software/${icon}`} alt="" loading="lazy" /><strong>{name}</strong><span>{detail}</span></div>)}</div><div className="software-heading creative-heading"><p className="kicker">AI & PHOTOGRAPHY</p><h3>拓展创意，也记录真实。</h3></div><div className="software-grid creative-grid">{creativeTools.map(([name, detail, icon]) => <div className="software-item" key={name}><img src={`/assets/software/${icon}`} alt="" loading="lazy" /><strong>{name}</strong><span>{detail}</span></div>)}</div><a className="icon-credit" href="https://icons8.com/icons" target="_blank" rel="noreferrer">Icons by Icons8</a></div>
        <div className="design-process" aria-label="设计流程">{["Research", "Concept", "Prototype", "Experience"].map((step, index) => <div key={step}><span>0{index + 1}</span><strong>{step}</strong></div>)}</div>
        <div className="metrics">{[["04", "SELECTED PROJECTS"], ["03+", "DESIGN AWARDS"], ["08+", "DESIGN TOOLS"], ["2023—27", "PRODUCT DESIGN, GUET"]].map(([value, label]) => <div key={label}><strong>{value}</strong><span>{label}</span></div>)}</div>
      </section>
      <section className="work section" id="work" data-scene>
        <div className="section-top"><p className="kicker"><span>02</span> SELECTED WORK</p><p className="section-note">Four projects across<br />health, home and ecology.</p></div><h2 className="scene-title work-title"><span>Objects with</span><span>stories to tell.</span></h2>
        <div className="work-grid">{projects.map(([tone, type, titleA, titleB, label, image, alt], index) => <article className={`work-card ${tone} reveal-card`} key={titleA}><a href={`#/work/${cases[index].slug}`} aria-label={`查看 ${titleA} ${titleB} 案例研究`}><div className="work-media"><img src={image} alt={alt} className={`parallax ${tone === "orange" ? "contain" : ""}`} /></div><div className="work-info"><span>{type}</span><h3>{titleA} {titleB}</h3><p>{label}</p><span className="arrow-icon card-arrow" aria-hidden="true" /></div><div className="case-card-link">VIEW CASE STUDY <Arrow /></div></a></article>)}</div>
      </section>
      <section className="skills section" id="skills" data-scene>
        <div className="section-top"><p className="kicker"><span>03</span> EXPERTISE</p><p className="section-note">Research to image.<br />Idea to object.</p></div><h2 className="scene-title"><span>From first thought</span><span>to final frame.</span></h2>
        <div className="skill-list">{skills.map(([title, text], index) => <article className="reveal-card" key={title}><span>0{index + 1}</span><h3>{title}</h3><p>{text}</p><span className="arrow-icon skill-arrow" aria-hidden="true" /></article>)}</div>
      </section>
      <section className="contact" id="contact" data-scene><div className="contact-orbit" /><p className="kicker"><span>04</span> CONTACT</p><h2 className="scene-title"><span>Make the next</span><span>object matter.</span></h2><div className="contact-bottom"><a href="mailto:427818148@qq.com">427818148@qq.com <span className="arrow-icon contact-arrow" aria-hidden="true" /></a><div><span>183 5607 6243</span><span>CHEN WENJING / 2026</span></div></div></section>
    </main>
  </>;
}




