import Arrow from "./Arrow.jsx";
const disciplines = ['INDUSTRIAL DESIGN', 'SMART HEALTHCARE', 'PRODUCT SYSTEM', 'USER RESEARCH'];

export default function Hero() {
  return <>
    <section className="hero-v2" id="home" aria-labelledby="hero-heading">
      <div className="hero-v2-image" aria-hidden="true"><img src="/assets/portfolio/p07-01.webp" alt="" fetchPriority="high" /></div>
      <div className="hero-v2-shade" />
      <div className="hero-v2-intro"><span className="hero-v2-dot" /> INDUSTRIAL DESIGNER <span className="hero-v2-name">CHEN WENJING / 陈文静</span></div>
      <h1 id="hero-heading"><span>DESIGNING</span><span>OBJECTS</span><span className="hero-v2-outline">FOR HUMAN</span><span>LIFE<span className="hero-v2-period">.</span></span></h1>
      <div className="hero-v2-description"><span className="hero-v2-label">A HUMAN PERSPECTIVE.</span><p className="hero-v2-statement">Human needs.<br />Thoughtful objects.</p><p>I explore the relationship between human needs, technology and form.</p><a href="#work">EXPLORE SELECTED WORK <Arrow /></a></div>
      <div className="hero-v2-bottom"><span>FROM RESEARCH TO PRODUCT FORM</span><span className="hero-v2-caption">FEATURED / KINESENSE PRO</span><a href="#about">SCROLL TO EXPLORE <Arrow direction="down" /></a></div>
    </section>
    <div className="hero-marquee" aria-label={disciplines.join(', ')}><div className="hero-marquee-track" aria-hidden="true">{[0, 1].map(copy => <div key={copy}>{disciplines.map(item => <span key={item}>{item}<svg className="marquee-symbol" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true"><path d="M12 2v20M2 12h20M5 5l14 14M5 19 19 5" /></svg></span>)}</div>)}</div></div>
  </>;
}
