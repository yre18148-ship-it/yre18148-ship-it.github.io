export default function Arrow({ direction = "up-right", className = "" }) {
 const paths = { "up-right":"M5 19 19 5M5 5h14v14", down:"M12 4v16M5 13l7 7 7-7", left:"M20 12H4m7-7-7 7 7 7" };
 return <svg className={`vector-arrow ${className}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false"><path d={paths[direction]} /></svg>;
}
