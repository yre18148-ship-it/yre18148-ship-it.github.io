import { enrichCases } from "./processDetails.js";
import { refineStories } from './storyDetails.js';
import { hyteraAssets } from './hyteraAssets.js';
const image = (name, caption) => ({ src: `/assets/cases/${name}.webp`, caption });
const existing = (name, caption) => ({ src: `/assets/portfolio/${name}.webp`, caption });
const hyteraFigure = (name, caption, note) => ({ src: hyteraAssets[name], caption, note });

export const cases = [
  {
    slug:'kinesense', number:'01', title:'KineSense Pro', category:'HEALTHCARE / WEARABLE SYSTEM', chinese:'智能运动康复设备',
    headline:'From protection\nto confidence.',
    intro:'以脚踝骨折居家康复为设计场景，将固定保护、动作反馈与阶段适配组织为一个产品系统，探索运动爱好者从术后恢复到重返运动的连续体验。',
    hero:'/assets/portfolio/p07-01.webp', theme:'sage', scope:['用户与竞品分析','模块化产品设计','移动端交互'],
    sections:[
      {id:'context',label:'问题与调研',eyebrow:'01 / CONTEXT & RESEARCH',title:'康复离开机构以后，\n指导如何继续？',text:'资料将居家康复的焦虑归纳为“不敢练、不会练、不知练得对不对”。项目从运动爱好者的恢复动机出发，关注训练动作、进度反馈以及不同阶段的产品适配。',
        cards:[['不敢练','对再次受伤的担忧，影响自主训练的信心。'],['不会练','专业指导与居家使用之间存在衔接问题。'],['反馈不清晰','训练过程难以形成直观、连续的进度感知。']],
        comparison:[['家用康复器械','以基础活动与力量训练为主','设计机会：补充动作感知与反馈'],['消费级可穿戴','以日常健康数据为主','设计机会：连接脚踝训练场景'],['线下康复指导','提供面对面的专业支持','设计机会：延续居家阶段的信息连接']],
        source:'依据《设计过程与方案》第 5、8–12、18–23 页的分析整理；属于项目分析，不代表已完成用户访谈。'},
      {id:'strategy',label:'洞察与策略',eyebrow:'02 / INSIGHT TO STRATEGY',title:'阶段在变化，\n产品也需要变化。',text:'资料中的旅程拆分提示：固定保护、训练反馈和运动复用并非同一种任务。设计因此采用分阶段模块组合，将硬件感知与移动端反馈联系起来。',
        journey:[['急性期','固定与保护','基础支撑与状态记录'],['恢复期','理解训练过程','动作反馈与训练记录'],['回归期','回到日常活动','足压与步态信息'],['维持期','衔接运动需求','防护复用与持续记录']],
        cards:[['SENSE / 感知','以关节与足压信息作为反馈系统的输入。'],['ADAPT / 适配','基础托与可拆卸模块对应不同阶段需求。'],['GUIDE / 引导','通过移动端将记录转化为可理解的训练信息。']],
        source:'依据过程资料第 33、35、40–41、47 页；阶段对应关系为概念方案，未作为临床使用方案验证。'},
      {id:'sketch',label:'草图探索',eyebrow:'03 / FORM EXPLORATION',title:'先探索佩戴关系，\n再收敛产品形态。',text:'草图围绕脚踝包覆、支撑边界与绑带布局展开。将侧面支撑、足底承托和连接位置放在一起阅读，可以看见不同形态方向如何逐步转化为完整的穿戴结构。',images:[image('kinesense-sketches','护踝形态、绑带与支撑结构的草图探索')],
        cards:[['包覆','观察产品与小腿、脚踝、足部的接触关系。'],['连接','梳理绑带、支撑件与可拆卸部件的组合。'],['形态','协调支撑感与运动产品的视觉语言。']]},
      {id:'development',label:'系统发展',eyebrow:'04 / PRODUCT SYSTEM',title:'从单件护具，\n到硬件与反馈系统。',text:'方案以基础支撑结构为载体，将智能护踝、足压监测鞋垫与移动端组织为三个互相关联的触点。基础托与固定模块构成穿戴形态，数字界面将感知信息连接到训练记录。',images:[image('kinesense-brace','智能护踝整体方案'),image('kinesense-base','基础承托结构方案')],
        cards:[['智能护踝','承载固定保护与关节感知的设计方向。'],['足压鞋垫','探索压力分布与步态信息的采集触点。'],['移动端','组织训练任务、状态记录和进度查看。']]},
      {id:'experience',label:'交互与场景',eyebrow:'05 / DIGITAL EXPERIENCE',title:'让数据变成\n看得懂的反馈。',text:'界面将训练任务与状态查看分开组织：先理解当前任务，再进入训练，最后回看过程记录。仪表、曲线和个人信息界面共同构成产品的数字体验提案。',images:[image('app-dashboard','训练与状态概览界面'),image('app-progress','数据与进度界面'),image('app-profile','个人信息与记录界面')],layout:'phones',
        closingImage:existing('p07-01','居家康复场景效果示意')},
      {id:'reflection',label:'反思与下一步',eyebrow:'06 / REFLECTION',title:'完整的概念闭环，\n仍需要真实使用来检验。',text:'本项目已呈现调研分析、草图、模块化方案和界面设计。下一步应优先验证佩戴舒适性、穿脱操作与模块连接，再与专业人员评估训练反馈逻辑。现有资料未提供临床验证、量产样机测试或算法精度结果。',cards:[['佩戴验证','以实体模型观察接触、重量与活动干涉。'],['交互验证','检查用户能否理解任务、反馈和状态。'],['技术验证','核验传感方案、可靠性与专业使用边界。']]}
    ],source:'《设计过程与方案》48 页；《作品集》第 4–7 页。'
  },
  {
    slug:'zenbrew',number:'02',title:'ZenBrew Hub',category:'HOME APPLIANCE / PRODUCT DESIGN',chinese:'智能茶吧机',headline:'A quieter\ndaily ritual.',
    intro:'将净水、加热与储物纳入统一的家居产品语言，用几何微曲面和克制的操作布局，探索日常饮茶与居住空间之间的连接。',hero:'/assets/portfolio/p12-01.webp',theme:'clay',scope:['场景与功能分析','形态探索','结构与 CMF'],
    sections:[
      {id:'context',label:'场景与命题',eyebrow:'01 / DESIGN CONTEXT',title:'从功能集合，\n回到日常饮茶。',text:'作品集将项目定位为净水、加热与底层储物的集成设计，并提出让泡茶回归日常仪式感。案例由此围绕操作台、取水与家居融入三个问题组织。现有资料以草图和方案图为主，未提供独立用户调研记录。',cards:[['操作台','如何让取水动作具有清晰的操作区域？'],['集成','如何将不同功能放入统一体量？'],['家居融入','如何减少家电的视觉冷硬感？']]},
      {id:'sketch',label:'草图探索',eyebrow:'02 / SKETCH & FORM',title:'用草图比较\n体量与操作关系。',text:'探索从柜体比例、顶部操作区和出水位置展开。草图中的轮廓变化，将“如何放入家中”与“如何使用”放在同一次形态推敲里。',images:[image('zenbrew-sketches','柜体比例、顶部操作台与出水结构的草图探索')]},
      {id:'structure',label:'结构发展',eyebrow:'03 / STRUCTURE DEVELOPMENT',title:'外部的简洁，\n需要内部的组织。',text:'结构图把外壳、内部组件与储物空间拆开呈现。网页通过结构关系解释一体化设计，再回到产品外观；现有图纸表达设计构成，未提供工程可制造性验证。',images:[image('zenbrew-structure','组件拆解与整体结构'),existing('p11-01','外壳、内部空间与储物结构的效果表达')]},
      {id:'form',label:'形态与 CMF',eyebrow:'04 / FORM & CMF',title:'克制的轮廓，\n柔和的家居表情。',text:'低饱和度雾灰与哑白、几何微曲面、顶部悬浮式操作台和水平出水构件，共同构成作品集提出的产品语言。通过大面积体块与细部的对照，让功能被整合进稳定的整体。',images:[existing('p10-02','产品结构与形态表达')]},
      {id:'experience',label:'场景与反思',eyebrow:'05 / SCENARIO & REFLECTION',title:'让功能进入空间，\n让体验接受检验。',text:'最终效果将产品放入室内环境，呈现体量、色彩与周边家具的关系。后续需要通过操作模型检查取水高度、杯具放置、清洁维护与储物可达性；现有资料尚未提供这些测试结果。',images:[existing('p12-01','室内场景与产品比例效果')],cards:[['操作','检查取水与杯具放置是否顺畅。'],['维护','检查清洁、补水与组件维护的路径。'],['空间','验证不同室内布局中的摆放与可达性。']]}
    ],source:'《作品集》第 8–12 页。'
  },
  {
    slug:'halo',number:'03',title:'Halo Breeze',category:'PERSONAL COMFORT / WEARABLE PRODUCT',chinese:'挂脖式风扇',headline:'Comfort\nin motion.',
    intro:'围绕挂脖式产品的佩戴关系，探索环形轮廓、风扇组件与外壳结构的组合，通过草图、尺寸表达和爆炸图呈现从形态到构成的过程。',hero:'/assets/portfolio/p18-01.webp',theme:'peach',scope:['佩戴场景分析','草图与形态设计','尺寸与结构表达'],
    sections:[
      {id:'context',label:'场景与命题',eyebrow:'01 / DESIGN CONTEXT',title:'戴在身上的产品，\n首先面对身体。',text:'场景图以日常活动中的佩戴为出发点。案例将颈部接触、两侧风扇布置和整体体量作为阅读设计过程的三个线索；这些属于对现有方案的设计分析，资料未提供佩戴访谈或实测记录。',cards:[['接触','颈部连接与表面过渡如何影响佩戴？'],['布局','两侧风扇与连接段如何共同形成体量？'],['活动','产品在日常活动中是否会干涉身体？']]},
      {id:'sketch',label:'形态草图',eyebrow:'02 / FORM EXPLORATION',title:'在环形轮廓中，\n寻找不同的佩戴表达。',text:'草图展示了开放环形、侧部体块和局部连接的多种方向。将这些变化并列呈现，可以把整体轮廓的探索与细节形态的收敛区分开。',images:[image('halo-sketches','挂脖轮廓与局部体块探索')]},
      {id:'development',label:'尺寸与结构',eyebrow:'03 / DIMENSION & CONSTRUCTION',title:'从一条轮廓，\n到可拆解的构成。',text:'尺寸表达与多视图补充外形关系，爆炸图则展开外壳、内部组件与连接段。先说明产品的整体尺度，再解释两侧风扇的构成，让形态发展具有清晰的阅读顺序。',images:[image('halo-views','产品多视图与环形关系'),image('halo-dimensions','整体尺寸与组件布局'),image('halo-fan','风扇组件尺寸表达')]},
      {id:'final',label:'最终方案',eyebrow:'04 / FINAL DESIGN',title:'把构成与颜色，\n放回完整产品。',text:'橙色与浅色方案提供两种视觉表达。爆炸图强调内部构成，完整效果则呈现佩戴产品的整体轮廓；色彩版本展示方案差异，不代表经过用户偏好测试。',images:[existing('p17-02','挂脖式风扇组件爆炸图'),existing('p17-03','不同配色下的完整产品表达')]},
      {id:'reflection',label:'场景与反思',eyebrow:'05 / SCENARIO & REFLECTION',title:'舒适需要\n在持续佩戴中验证。',text:'场景效果建立了日常使用的想象。下一步应使用实体样机检查重量分配、接触舒适度、活动干涉与噪声，同时验证气流方向和热舒适表现。现有资料未提供上述实测结果。',images:[existing('p18-01','日常室内佩戴场景示意')]}
    ],source:'《作品集》第 13–18 页。'
  },
  {
    slug:'aqua',number:'04',title:'AQUA Sentinel',category:'ECOLOGICAL SYSTEM / CONCEPT DESIGN',chinese:'海域哨卫概念设计',headline:'A system\nfor the sea.',
    intro:'以海洋生态议题为出发点，将海面平台、下方结构和外围模块组织为一个概念系统，通过形态草图、分解图与场景图展开方案。',hero:'/assets/cases/aqua-main.jpg',theme:'ocean',scope:['环境议题分析','系统形态探索','结构与场景表达'],
    sections:[
      {id:'context',label:'背景与命题',eyebrow:'01 / DESIGN CONTEXT',title:'从海洋生态议题，\n进入系统设计。',text:'作品集以海洋污染和生态保护作为选题背景。网页将这一背景连接到平台、模块与海域场景的关系，围绕系统如何被组织展开叙事。资料尚未提供现场调研或环境效果验证。',cards:[['环境','海域场景如何影响平台布局？'],['系统','中心结构与外围模块如何组织？'],['维护','不同组件如何被理解与维护？']]},
      {id:'sketch',label:'概念草图',eyebrow:'02 / SYSTEM EXPLORATION',title:'先理解系统关系，\n再形成整体轮廓。',text:'草图围绕圆形平台、外围单元和下方结构展开。不同形态方向不仅改变外观，也改变部件之间的组合关系。',images:[image('aqua-sketches','平台与模块关系的草图探索'),image('aqua-development','整体与局部结构的发展草图')]},
      {id:'structure',label:'结构发展',eyebrow:'03 / SYSTEM DEVELOPMENT',title:'从中心平台，\n展开不同层级。',text:'分解图将上部平台、外围模块与水下结构分别展开，让系统层级能够被逐步阅读。以下呈现的是概念构成，不能由渲染图推断实际部署性能。',images:[existing('p21-03','中心平台与内部结构表达'),existing('p22-03','系统组件与分解关系')]},
      {id:'final',label:'最终概念',eyebrow:'04 / CONCEPT IN CONTEXT',title:'将复杂系统，\n放回海域场景。',text:'海面效果与系统展示图共同呈现方案的空间关系：先看到整体，再识别平台与外围组件。最终视觉用于表达设计意图，尚不构成运行、生态效果或结构可靠性的证明。',images:[existing('p23-01','海域场景与概念系统展示')]},
      {id:'reflection',label:'反思与边界',eyebrow:'05 / REFLECTION',title:'概念的下一步，\n是明确真实边界。',text:'后续需要明确系统承担的具体任务、部署条件与维护流程，再评估海上稳定性、材料耐久性、能源供给和环境影响。现阶段保留概念设计定位，避免把视觉完成度等同于工程成熟度。',cards:[['任务定义','明确平台与各模块承担的具体工作。'],['工程评估','验证海上环境中的稳定性与维护条件。'],['环境评估','明确生态影响的评估方法与证据。']]}
    ],source:'《作品集》第 19–24 页。'
  },
  {
    slug:'hytera',number:'05',title:'Hytera Outdoor',category:'OUTDOOR SAFETY / COMMUNICATION CONCEPT',chinese:'海能达户外应急通信概念',
    headline:'Connection for\nthe trail.',
    intro:'从结伴徒步中的失联与求助场景出发，把团队研究转化为一款随身通信终端概念。重点回应行进中的快速操作、不同位置的携带，以及紧急情况下让附近人员发现自己的需求。',
    hero:hyteraAssets.hero,theme:'alpine',scope:['户外用户与竞品研究','产品形态与操作设计','携带方式与 CMF'],
    credit:'前期调研由陈丽雪、陈文静、方笑雯组成的直上组共同完成；终端的产品定位、操作细节、携带方式、场景表达及 CMF 方案由陈文静呈现。',
    sections:[
      {id:'context',label:'人群与命题',eyebrow:'01 / PEOPLE & CONTEXT',title:'当信号消失，\n安全感从哪里来？',text:'团队比较资深长线徒步者、专业探险者与轻户外人群，将 6–8 天长线徒步中的资深户外爱好者选为核心对象。它既需要可靠的通信与定位，也在意重量、佩戴和紧急状态下的操作负担。这里的人群分类属于项目研究与设计判断，并非独立访谈样本。',
        metrics:[['03','对比人群'],['6–8 天','核心徒步场景'],['01','随身终端方向']],
        matrix:{headers:['人群','主要任务','方案取舍'],rows:[['资深长线徒步者 · 核心对象','队员沟通、路线查看与遇险求助','兼顾专业功能与日常携带'],['专业探险者','极端环境下的高可靠通信','需求更严苛，概念方案不宣称已满足专业认证'],['轻户外休闲者','偶发失联时快速求助','操作须直观，但避免为低频需求堆叠功能']]},matrixLabel:'目标人群选择'},
      {id:'journey',label:'场景与信息断点',eyebrow:'02 / JOURNEY & CONDITIONS',title:'从出发到遇险，\n把信息断点找出来。',text:'团队将出发准备、行进、停留与紧急情况连成一条旅程。夜间林地、峡谷遮挡、雨雪与戴手套操作等情境，分别影响目标可发现性、通信连续性和按键可达性。大图保留原研究关系，下面把它压缩为可阅读的设计任务。',
        images:[hyteraFigure('journey','户外活动旅程与设计切入点','团队研究：从用户行为、环境状态和信息需求识别关键断点。'),hyteraFigure('weather','天气与环境问题矩阵','不同条件下的操作、定位和求助需求。')],
        flow:[['出发','检查设备、路线与队友状态'],['行进','查看路线并保持小队联系'],['停留','取下设备确认位置与状态'],['遇险','快速触发求助并获得明确反馈']],
        matrix:{headers:['场景中的问题','设计机会','方案回应'],rows:[['手套、低温和紧张状态增加操作难度','减少应急操作步骤','实体按键分区，SOS 长按触发'],['夜间或遮挡环境难以被附近人员发现','在定位信息之外增加近距离提示','扬声器啸叫与可识别的设备位置'],['设备挂在背包上却不易及时取用','兼顾固定和快速挂取','背夹与顶部快挂两种携带方式']]},matrixLabel:'从场景走向产品任务'},
      {id:'research',label:'竞品与设计机会',eyebrow:'03 / PRODUCT LANDSCAPE',title:'功能很多，\n操作路径需要更短。',text:'团队对照卫星通信器、对讲机和综合通信终端，观察尺寸、按键、屏幕、佩戴与求救入口的取舍。不同产品各有适用边界；本项目把“队内沟通、路线参考、应急反馈”整合为概念方向，不把尚未验证的通信性能写成产品成果。',
        matrix:{headers:['参考类型','调研观察','本方案的选择'],rows:[['卫星通信器','求救与位置能力突出，部分操作依赖配套设备','保留独立的应急操作入口'],['户外对讲机','实体操作直接，但体量与挂载方式偏工具化','将常用按钮与随身佩戴一起考虑'],['综合通信终端','功能集中，信息层级与学习成本更高','只让屏幕承载路线和状态等必要信息']]},matrixLabel:'竞品观察与方案方向'},
      {id:'sketch',label:'草图与方案收敛',eyebrow:'04 / FORM EXPLORATION',title:'从掌心设备，\n走向背包上的工具。',text:'早期草图比较了圆润随身设备、卡扣挂载、翻盖保护与滑盖开合。方向逐步收敛为约 90 × 50 × 30 mm 的随身终端概念：顶部便于挂取，正面保持清晰的屏幕与按键区，滑盖在停留时展开扬声器。尺寸为概念阶段的设计设定。',
        images:[hyteraFigure('sketchA','早期方向 / 掌心尺寸与一键求助','从小体量和快速触发出发。'),hyteraFigure('sketchB','挂载方向 / 卡扣、背夹与佩戴位置','比较随身携带和取用关系。'),hyteraFigure('sketchC','结构方向 / 翻盖与保护构件','探索遮护、按键与装配边界。'),hyteraFigure('sketchD','收敛方向 / 滑盖、快挂与操作面','将产品外形和日常使用动作放在一起推敲。')],layout:'two-column',
        decisions:[['随身携带','设备在行进中要能快速摸到并稳定固定。','采用背夹与顶部快挂，减少取放步骤。'],['紧急入口','慌乱时需要与日常按键明显区分。','将 SOS 置于正面，并采用长按与取消时间的交互设想。'],['功能层级','路线查看与营地播放属于不同状态。','滑盖收起时保持紧凑，展开后露出扬声器区域。']]},
      {id:'development',label:'操作与携带',eyebrow:'05 / PRODUCT DEVELOPMENT',title:'常用操作可达，\n紧急操作可辨。',text:'个人方案将墨水屏、方向键、SOS、电源与侧键分区，背部提供背夹，顶部设置快挂。行进时设备可固定在肩带或腰带，停留时取下查看路线，滑盖展开后使用扬声器。以下场景图表达使用方式，并不代表已完成野外实测。',
        images:[hyteraFigure('productDetails','正反面与滑盖结构','把屏幕、按钮、扬声器和背夹放进同一套操作逻辑。'),hyteraFigure('wearing','徒步中的携带与手持场景效果','展示肩带挂载和取下查看两种状态。')],
        matrix:{headers:['触点','预期动作','设计回应'],rows:[['背夹 / 快挂','固定、转移佩戴位置','肩带、腰带及装备挂环的携带选择'],['墨水屏 / 方向键','查看路线与设备状态','低干扰的信息区与实体操作区'],['SOS / 扬声器','遇险时提醒附近人员','长按触发设想与声音提示'],['滑盖','停留时切换使用状态','展开后露出扬声器区域']]},matrixLabel:'操作触点与使用状态'},
      {id:'cmf',label:'色彩与材质',eyebrow:'06 / CMF & DETAIL',title:'在户外可识别，\n也能融入装备。',text:'正面苔绿、背部炭黑、侧面天蓝建立清晰的部件层级。灰白按键与低反光屏幕控制阅读干扰，橙色电源键提供小面积操作强调。PC+ABS、局部 TPU 与硅胶按键是概念阶段的材料与表面处理提案。',
        images:[hyteraFigure('cmf','CMF / 正面、背面与侧面关系','用色彩区分操作面、握持面与侧向轮廓。'),hyteraFigure('productBlue','蓝色方案 / 掌心尺度的产品表达','侧面按键和顶部快挂的整体关系。')],layout:'two-column',
        matrix:{headers:['部位','提案材料与颜色','设计意图'],rows:[['正面外壳','苔绿色 PC+ABS · 细砂纹哑光','保留户外装备的识别度'],['背壳','炭黑色 PC+ABS · 局部 TPU','减少视觉干扰并关注握持'],['侧壳与按键','天蓝色侧壳 · 灰白硅胶按键','明确轮廓和操作位置']]},matrixLabel:'概念 CMF 配置'},
      {id:'final',label:'最终概念',eyebrow:'07 / CONCEPT OUTCOME',title:'随身携带，\n快速操作，声音求助。',text:'最终概念把背夹、快挂、屏幕和实体按钮组织在掌心大小的设备上。滑盖与扬声器为停留和紧急状态提供另一种使用方式。渲染图说明设计意图；通信覆盖、红外识别、防护等级和续航仍需工程验证。',
        images:[hyteraFigure('hero','海能达户外应急通信概念 / 三视角方案','苔绿、炭黑与天蓝的产品关系。')]}
    ],source:'《直上组》49 页；团队署名见第 1 页，陈文静个人方案见第 44–49 页。'
  }
];


enrichCases(cases);
refineStories(cases);
