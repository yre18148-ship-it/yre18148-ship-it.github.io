import hero from './assets/hytera/hytera-hero.webp';
import journey from './assets/hytera/hytera-journey.webp';
import weather from './assets/hytera/hytera-weather.webp';
import sketchA from './assets/hytera/hytera-sketch-a.webp';
import sketchB from './assets/hytera/hytera-sketch-b.webp';
import sketchC from './assets/hytera/hytera-sketch-c.webp';
import sketchD from './assets/hytera/hytera-sketch-d.webp';
import productBlue from './assets/hytera/hytera-product-blue.webp';
import productDetails from './assets/hytera/hytera-product-details.webp';
import wearing from './assets/hytera/hytera-wearing.webp';
import cmf from './assets/hytera/hytera-cmf.webp';

export const hyteraAssets = {
  hero, journey, weather, sketchA, sketchB, sketchC, sketchD,
  productBlue, productDetails, wearing, cmf,
};
