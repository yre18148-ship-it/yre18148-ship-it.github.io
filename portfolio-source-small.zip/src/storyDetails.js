import kinesenseProductExploded from './assets/kinesense-product-exploded.webp';

const asset = (name, caption, note, monochrome = false) => ({src: `/assets/cases/${name}`, caption, note, monochrome});
const render = (name, caption, note) => ({src: `/assets/portfolio/${name}.webp`, caption, note});

export function refineStories(cases) {
  const project = slug => cases.find(p => p.slug === slug);
  const section = (slug, id) => project(slug).sections.find(s => s.id === id);
  const insert = (slug, after, value) => {
    const p = project(slug);
    p.sections.splice(p.sections.findIndex(s => s.id === after) + 1, 0, value);
  };
  const k = section('kinesense', 'context');
  k.title = '从恢复日常，\n到重新回到运动。';
  k.text = '比较四类候选人群后，项目聚焦运动爱好者。他们的恢复目标从日常行走延伸到运动复用，因此固定保护、动作反馈和阶段适配需要被放在同一个系统中考虑。';
  delete k.metrics;
  delete k.cards;
  const comparison = k.comparison;
  delete k.comparison;
  insert('kinesense', 'context', {
    id: 'benchmark', label: '竞品对照', eyebrow: '02 / PRODUCT LANDSCAPE',
    title: '器械提供动作，\n系统还需要反馈。',
    text: '调研中的家用器械以踏蹬、牵拉和阻力运动为主要形式。项目进一步比较家用器械、消费级穿戴与专业指导的任务边界，将“脚踝动作与连续反馈的连接”作为设计切入点。',
    images: [asset('kinesense-reference-1.jpg', '调研参考 / 小型踏蹬器械', '通过踏板组织重复活动。'), asset('kinesense-reference-2.jpg', '调研参考 / 上下肢组合器械', '观察身体姿态、占地与操作触点。'), asset('kinesense-reference-3.jpg', '调研参考 / 弹力带训练', '从牵拉动作观察器材与身体的关系。')],
    layout: 'reference-strip', comparison
  });
  const brief = section('kinesense', 'brief');
  brief.text = '训练前需要知道做什么，训练中需要理解动作，训练后需要看见记录。以这三个信息断点定义硬件与界面的分工：护具承载接触与感知，界面组织任务与反馈。';
  delete brief.flow;
  const strategy = section('kinesense', 'strategy');
  strategy.text = '保护、训练、日常活动与运动复用对应不同任务。基础承托保持连续，可拆卸组件随任务组合；移动端将不同阶段的记录放在同一条使用路径中。';
  delete strategy.cards;
  const sketch = section('kinesense', 'sketch');
  sketch.images = [asset('kinesense-moodboard.jpg', '设计语言 / 柔和色彩、亲肤表面与连续曲面', '情绪板用于建立形态与材质方向，参考图与产品方案分开阅读。'), asset('kinesense-ideation.webp', '形态展开 / 包覆、开孔与支撑边界', '并列观察不同包覆程度、绑带布局和足底承托关系。', true)];
  delete sketch.cards;
  delete sketch.decisions;
  insert('kinesense', 'sketch', {
    id: 'refinement', label: '模块推敲', eyebrow: '06 / DETAIL REFINEMENT',
    title: '支撑与感知，\n在佩戴结构中相遇。',
    text: '从大范围形态展开进入局部推敲：足底与侧向结构形成承托，绑带组织固定方向，分件草图解释连接位置。把这些关系拆开呈现，能看见完整轮廓背后的设计安排。',
    images: [asset('kinesense-module-study.webp', '局部推敲 / 包覆与可拆卸构件', '由整体穿戴关系进入模块、连接与绑带的细化。', true), asset('kinesense-fit-study.webp', '方向细化 / 侧向支撑与足底承托', '结合侧面与正面阅读支撑边界。', true)], layout: 'two-column',
    decisions: [['支撑边界', '侧向结构与足底承托承担不同接触关系。', '通过分件表达保留基础承托，让组合方式容易理解。'], ['固定方向', '绑带跨越脚背与小腿，连接位置影响穿戴操作。', '用正侧视图同时说明固定路径与轮廓关系。']]
  });
  const dev = section('kinesense', 'development');
  dev.images = [asset('kinesense-brace.webp', '智能护踝整体方案'), {src: kinesenseProductExploded, caption: '智能护踝 / 产品分层效果图', note: '通过分层视图展示外部护具与感知组件的组合关系。'}];
  dev.text = '智能护踝、足压鞋垫与移动端形成三个触点。护踝回应固定与关节感知，鞋垫补充足底信息，界面承接训练任务与记录，构成硬件与信息相互连接的概念系统。';
  delete dev.cards;
  dev.matrix.headers = ['触点', '设计职责', '对应信息'];
  dev.matrix.rows = [['智能护踝', '承托、固定与关节感知', '佩戴状态与动作过程'], ['足压鞋垫', '补充足底压力与步态信息', '受力分布与活动记录'], ['移动端', '组织任务、反馈与回看', '当天任务、训练状态与历史进度']];
  insert('kinesense', 'development', {
    id: 'interface', label: '交互方案', eyebrow: '08 / DIGITAL EXPERIENCE',
    title: '从感知信息，\n到可阅读的训练记录。',
    text: '界面先呈现当天任务与状态，再组织训练和进度回看。以下为概念界面，图中的数值用于表达信息层级，不是使用测试或疗效数据。',
    images: [asset('app-dashboard.webp', '任务与状态概览'), asset('app-progress.webp', '数据与进度回看'), asset('app-profile.webp', '个人记录与管理')], layout: 'phones'
  });

  const z = section('zenbrew', 'context');
  z.title = '一次取水，\n也是一次空间使用。';
  z.text = '从放杯、取水到归置用品，日常动作连接着上部台面与下部储物。设计以清晰的操作区、统一的柜体和温和的家居表情回应这组任务。';
  delete z.cards;
  z.matrix.headers = ['使用任务', '空间安排', '形态回应'];
  z.matrix.rows = [['放杯与取水', '把杯具、出水口和操作放在同一区域', '水平出水构件与清晰的顶部台面'], ['归置用品', '将储物放在柜体下层', '上下层分区，维持整体轮廓'], ['日常摆放', '与周边家具建立体量关系', '低饱和灰白、几何微曲面与柔和过渡']];
  const zs = section('zenbrew', 'sketch');
  zs.title = '从有机曲线，\n收敛到几何秩序。';
  zs.text = '先展开柜体与出水构件的形态，再分别收敛。柜体从流线轮廓走向几何体块；水龙头从连续曲面过渡到 L 形截面，使上下部形成一致的设计语言。';
  zs.images = [asset('zenbrew-body-evolution.webp', '柜体演变 / 曲线体量 → 几何柜体', '观察下部稳定体量与上部操作区如何逐步分开。', true), asset('zenbrew-faucet-evolution.webp', '出水构件演变 / 有机曲面 → L 形截面', '局部轮廓从柔和曲线转向明确的方向与边界。', true)];
  delete zs.decisions;
  insert('zenbrew', 'sketch', {
    id: 'iteration', label: '台面推敲', eyebrow: '03 / PLATFORM STUDY',
    title: '细化取水关系，\n再整合操作台面。',
    text: '台面探索比较杯具区域、圆形操作区与水龙头底座的位置。选定方向将这些触点纳入薄型矩形平台，保留柔和边缘，同时让出水方向容易识别。',
    images: [asset('zenbrew-platform-options.webp', '局部探索 / 操作区与出水位置', '比较不同底座、圆形区域与出水构件的组合。', true), asset('zenbrew-platform-evolution.webp', '方案收敛 / 薄型矩形操作平台', '由圆润底座逐步进入平整台面与几何边界。', true)], layout: 'two-column',
    decisions: [['操作区', '圆形触点与杯具区域在不同方向中重新组合。', '以一块完整平台统一操作与取水，减少零散构件。'], ['出水方向', '曲面和折线构件带来不同的方向感。', '用 L 形轮廓清楚表达竖向支撑与水平出水。']]
  });
  section('zenbrew', 'structure').text = '将外壳、内部组件与储物空间拆开，再回到完整柜体。分解图说明内部空间的安排，外观图呈现功能如何被整合进统一体量。';
  const form = section('zenbrew', 'form');
  form.images = [asset('zenbrew-form-study.png', '产品结构与形态表达', '通过整体、局部与拆分视图阅读柜体、台面和出水构件。', true), render('p12-01', '最终方案 / 灰白体量与室内场景', '在家居环境中观察色彩、比例与产品的整体表情。')];
  form.text = '雾灰与哑白、几何微曲面和水平出水构件形成克制的产品语言。白底线稿说明结构与轮廓，室内效果图则呈现它与居住空间的关系。';

  const h = section('halo', 'context');
  h.images = [render('p18-01', '场景表达 / 颈部接触与日常佩戴', '通过场景图观察开放轮廓、两侧体量与身体的关系。')];
  h.text = '颈部连接决定身体接触，两侧体块组织风扇组件，开放轮廓为戴入和活动留出空间。设计围绕这三组关系展开，先读佩戴，再读形态与组件。';
  delete h.cards;
  h.matrix.headers = ['佩戴关注', '图中观察', '设计回应'];
  h.matrix.rows = [['颈部接触', '连接段与身体表面的关系', '连续曲面与柔和过渡'], ['两侧体量', '风扇壳体与连接段的比例', '对称组织组件与形态'], ['戴入与活动', '开放轮廓和两侧间距', '以开放环形组织佩戴方向']];
  const hs = section('halo', 'sketch');
  hs.images = [asset('halo-ideation.webp', '形态展开 / 开放轮廓、侧部体量与送风构件', '在同一张探索板中比较整体轮廓、出风布局与组件关系。', true)];
  delete hs.decisions;
  insert('halo', 'sketch', {
    id: 'refinement', label: '局部推敲', eyebrow: '03 / WEARING & FORM',
    title: '让两侧体量，\n沿着连接段连续过渡。',
    text: '局部草图从连接弧线和侧部体块进入细化。正侧面的轮廓对照帮助协调转折、开口和两侧体量，让环形产品保持统一的佩戴方向。',
    images: [asset('halo-form-study.webp', '轮廓推敲 / 连接段与两侧构件', '观察颈部曲线与侧部体块之间的过渡。', true), asset('halo-connection-study.webp', '连续性推敲 / 环形连接与侧部体量', '以完整轮廓检查两侧构件如何融入连接段。', true)], layout: 'two-column'
  });
  const hd = section('halo', 'development');
  hd.layout = 'technical';
  hd.text = '先以多视图说明整体轮廓，再进入连接段和风扇组件的尺寸表达。不同图纸各自回答一个问题：产品如何环绕身体、两侧如何布置、组件如何形成构成。';
  hd.matrix.headers = ['图纸', '阅读重点', '设计信息'];
  hd.matrix.rows = [['多视图', '正面、侧面与环形关系', '整体方向和两侧构件的对应'], ['整体尺寸', '连接段与侧部体量的比例', '产品尺度与组件布局'], ['局部尺寸', '风扇构件的边界与接口', '构件层级和装配表达']];
  section('halo', 'final').text = '组件爆炸图与完整配色方案形成对照：先阅读构件，再回到完整产品。橙色与浅色版本展示不同的视觉表情。';
  section('halo', 'final').layout = 'two-column';

  section('aqua', 'iteration').text = '从初始 20 套方案进入 6 套优化草图。重点比较平台完整性、能源板布局和外围模块识别，将选定方向继续转化为三维表达与实体展示模型。';
  section('aqua', 'sketch').layout = 'two-column';
  section('aqua', 'model').text = '拆分零件、组装关系与表面处理构成实体展示模型的制作过程。部件和整体照片补充三维渲染，让中心平台、外围模块与水下结构的比例可以被观察。';
  delete section('aqua', 'model').cards;
  section('aqua', 'model').images.forEach((i, n) => i.note = ['从分件观察中心、外围与下部结构的组成。', '组装后观察整体轮廓与模块识别。', '从侧面观察连接与上下层关系。'][n]);
  section('aqua', 'final').text = '海面场景呈现整体，功能图说明细部。两者共同表达母体平台、处理仓与子体的协作概念；实体展示模型补充了方案的形态与构成。';
  for (const p of cases) for (const [index, s] of p.sections.entries()) s.eyebrow = s.eyebrow.replace(/^\d+/, String(index + 1).padStart(2, '0'));
}
