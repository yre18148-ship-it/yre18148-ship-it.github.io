import Arrow from './Arrow.jsx';
import { useEffect, useRef, useState } from 'react';
import { cases } from './cases';
import './case-study.css';

function Figure({ item, onOpen, index }) {
  return <figure className={`case-figure ${item.monochrome ? 'paper-drawing' : ''}`}>
    <button className="figure-open" onClick={() => onOpen(item)} aria-label={`查看大图：${item.caption}`}>
      <img src={item.src} alt={item.caption} loading="lazy" />
      <span className="figure-zoom" aria-hidden="true"><Arrow /></span>
    </button>
    <figcaption><div>{index != null && <small>{String(index + 1).padStart(2, '0')} / </small>}{item.caption}{item.note && <p>{item.note}</p>}</div><button onClick={() => onOpen(item)}>查看大图 <Arrow /></button></figcaption>
  </figure>;
}

function ImageViewer({ item, onClose }) {
  const dialog = useRef(null);
  const [expanded, setExpanded] = useState(false);
  useEffect(() => {
    const modal = dialog.current;
    const previousFocus = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    modal.showModal();
    return () => {
      modal.close();
      document.body.style.overflow = previousOverflow;
      previousFocus?.focus();
    };
  }, []);
  return <dialog ref={dialog} className="image-viewer" aria-label={item.caption} onCancel={onClose} onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div className="viewer-toolbar"><p>{item.caption}</p><div><button onClick={() => setExpanded(value => !value)} aria-pressed={expanded}>{expanded ? '适应屏幕' : '放大图片'}</button><button autoFocus onClick={onClose}>关闭 <span aria-hidden="true">×</span></button></div></div>
    <div className={`viewer-canvas ${expanded ? 'expanded' : ''} ${item.monochrome ? 'paper-drawing' : ''}`}><img src={item.src} alt={item.caption} /></div>
  </dialog>;
}

function Matrix({ matrix, label = '设计分析' }) {
  return <div className="research-matrix" role="region" aria-label={label} tabIndex={0}><table><caption>{label}</caption><thead><tr>{matrix.headers.map(h => <th scope="col" key={h}>{h}</th>)}</tr></thead><tbody>{matrix.rows.map((row, i) => <tr key={i}>{row.map((cell, j) => j === 0 ? <th scope="row" key={j}>{cell}</th> : <td key={j}>{cell}</td>)}</tr>)}</tbody></table></div>;
}

function ProcessBlocks({ section }) {
  return <>
    {section.flow && <ol className="task-flow" aria-label="任务流程">{section.flow.map(([name, text], i) => <li key={name}><span>{String(i + 1).padStart(2, '0')}</span><div><h3>{name}</h3><p>{text}</p></div>{i < section.flow.length - 1 && <Arrow direction="right" />}</li>)}</ol>}
    {section.matrix && <Matrix matrix={section.matrix} label={section.matrixLabel || '分析与设计回应'} />}
    {section.journey && <Matrix matrix={{ headers: ['阶段', '核心任务', '产品触点'], rows: section.journey }} label="阶段与产品触点" />}
    {section.comparison && <Matrix matrix={{ headers: ['方案类型', '现有侧重', '设计机会'], rows: section.comparison }} label="竞品类型对照" />}
    {section.decisions && <div className="decision-list"><p className="case-eyebrow">READING THE SKETCHES / 草图中的设计取舍</p>{section.decisions.map(([topic, observation, response], i) => <article key={topic}><span>{String(i + 1).padStart(2, '0')}</span><div><h3>{topic}</h3><p>{observation}</p></div><p className="decision-response">{response}</p></article>)}</div>}
    {section.cards && !section.matrix && !section.decisions && <div className="case-insights">{section.cards.map(([title, text]) => <article key={title}><h3>{title}</h3><p>{text}</p></article>)}</div>}
  </>;
}

export default function CaseStudy({ project }) {
  const [active, setActive] = useState(project.sections[0].id);
  const [image, setImage] = useState(null);
  useEffect(() => {
    document.title = `${project.title} | Chen Wenjing`;
    setActive(project.sections[0].id);
    setImage(null);
    const observer = new IntersectionObserver(entries => {
      entries.filter(e => e.isIntersecting).forEach(e => setActive(e.target.id));
    }, { rootMargin: '-20% 0px -55% 0px', threshold: 0 });
    document.querySelectorAll('.case-section').forEach(section => observer.observe(section));
    return () => observer.disconnect();
  }, [project]);
  const next = cases[(cases.indexOf(project) + 1) % cases.length];
  return <div className={`case-page ${project.theme}`}>
    <header className="case-header"><a href="#home" className="case-wordmark">CW<span>.</span></a><a href="#work"><Arrow direction="left" /> ALL PROJECTS</a><a href="mailto:427818148@qq.com">LET'S TALK <Arrow /></a></header>
    <main>
      <section className="case-cover"><div className="case-cover-copy"><p className="case-eyebrow">CASE STUDY / {project.number} — {project.category}</p><h1>{project.title}</h1><p className="case-chinese">{project.chinese}</p><h2>{project.headline.split('\n').map(line => <span key={line}>{line}</span>)}</h2><p className="case-intro">{project.intro}</p><div className="case-meta"><div><span>DESIGNER</span><strong>陈文静 / Chen Wenjing</strong></div><div><span>SCOPE</span><strong>{project.scope.join(' / ')}</strong></div><div><span>STATUS</span><strong>概念设计 / Concept design</strong></div></div></div><figure className="case-cover-image"><img src={project.hero} alt={`${project.title} 项目主视觉`} fetchPriority="high" /><figcaption>DESIGN IN CONTEXT / {project.number}</figcaption></figure></section>
      <div className="case-body"><aside className="case-sidebar"><p>THE DESIGN STORY</p><nav aria-label="案例章节导航">{project.sections.map((section, index) => <a key={section.id} href={`#/work/${project.slug}/${section.id}`} onClick={() => document.getElementById(section.id)?.scrollIntoView({ behavior: 'instant' })} aria-current={active === section.id ? 'location' : undefined}><span>{String(index + 1).padStart(2, '0')}</span>{section.label}</a>)}</nav><a className="case-back" href="#work"><Arrow direction="left" /> 返回作品</a></aside>
        <div className="case-chapters">{project.sections.map(section => <section className="case-section" id={section.id} key={section.id}>
          <div className="chapter-heading"><div><p className="case-eyebrow">{section.eyebrow}</p><h2>{section.title.split('\n').map(line => <span key={line}>{line}</span>)}</h2></div><p className="case-prose">{section.text}</p></div>
          {section.metrics && <div className="research-metrics">{section.metrics.map(([value, label]) => <div key={label}><strong>{value}</strong><span>{label}</span></div>)}</div>}
          {section.images && <div className={`case-gallery ${section.layout || ''}`}>{section.images.map((item, index) => <Figure key={item.src} item={item} index={section.images.length > 1 ? index : undefined} onOpen={setImage} />)}</div>}
          <ProcessBlocks section={section} />
          {section.closingImage && <Figure item={section.closingImage} onOpen={setImage} />}
        </section>)}</div>
      </div>
      <a className="case-next" href={`#/work/${next.slug}`}><span>NEXT CASE STUDY / {next.number}</span><strong>{next.title}<Arrow className="next-arrow" /></strong><p>{next.chinese}</p></a>
    </main>
    <footer className="case-footer"><a href="#work"><Arrow direction="left" /> 所有作品</a><span>CHEN WENJING / INDUSTRIAL DESIGN</span><a href="mailto:427818148@qq.com">CONTACT <Arrow /></a></footer>
    {image && <ImageViewer key={image.src} item={image} onClose={() => setImage(null)} />}
  </div>;
}
