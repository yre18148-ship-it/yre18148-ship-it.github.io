import Arrow from "./Arrow.jsx";
import { useEffect, useState } from 'react';
import { cases } from './cases';
import './case-study.css';

function Figure({ item }) {
  return <figure className="case-figure"><a href={item.src} target="_blank" rel="noreferrer" aria-label={`查看大图：${item.caption}`}><img src={item.src} alt={item.caption} loading="lazy" /></a><figcaption>{item.caption}<span><Arrow /> 查看大图</span></figcaption></figure>;
}

function ProcessBlocks({ section }) {
 return <>
 {section.metrics && <div className="research-metrics" aria-label="设计过程概览">{section.metrics.map(([value,label])=><div key={label}><strong>{value}</strong><span>{label}</span></div>)}</div>}
 {section.flow && <ol className="task-flow" aria-label="任务流程">{section.flow.map(([name,text],i)=><li key={name}><span className="flow-index">{String(i+1).padStart(2,'0')}</span><h3>{name}</h3><p>{text}</p></li>)}</ol>}
 {section.matrix && <div className="research-matrix"><table><thead><tr>{section.matrix.headers.map(h=><th scope="col" key={h}>{h}</th>)}</tr></thead><tbody>{section.matrix.rows.map((row,i)=><tr key={i}>{row.map((cell,j)=>j===0?<th scope="row" key={j}>{cell}</th>:<td key={j} data-label={section.matrix.headers[j]}>{cell}</td>)}</tr>)}</tbody></table></div>}
 {section.decisions && <div className="decision-list"><p className="case-eyebrow">DESIGN DECISIONS / 设计推敲</p>{section.decisions.map(([topic,observation,response],i)=><article key={topic}><span>{String(i+1).padStart(2,'0')}</span><div><h3>{topic}</h3><p>{observation}</p></div><div className="decision-response"><small>设计回应</small><p>{response}</p></div></article>)}</div>}
 </>;
}

export default function CaseStudy({ project }) {
  const [active, setActive] = useState(project.sections[0].id);
  useEffect(() => {
    document.title = `${project.title} | Chen Wenjing`;
    setActive(project.sections[0].id);
    const observer = new IntersectionObserver(entries => {
      entries.filter(e => e.isIntersecting).forEach(e => setActive(e.target.id));
    }, { rootMargin:'-20% 0px -55% 0px', threshold:0 });
    document.querySelectorAll('.case-section').forEach(section => observer.observe(section));
    return () => observer.disconnect();
  }, [project]);
  const next = cases[(cases.indexOf(project) + 1) % cases.length];
  return <div className={`case-page ${project.theme}`}>
    <header className="case-header"><a href="#home" className="case-wordmark">CW<span>.</span></a><a href="#work"><Arrow direction="left" /> ALL PROJECTS</a><a href="mailto:427818148@qq.com">LET'S TALK <Arrow /></a></header>
    <main>
      <section className="case-cover"><div className="case-cover-copy"><p className="case-eyebrow">CASE STUDY / {project.number} — {project.category}</p><h1>{project.title}</h1><p className="case-chinese">{project.chinese}</p><h2>{project.headline.split('\n').map(line => <span key={line}>{line}</span>)}</h2><p className="case-intro">{project.intro}</p><div className="case-meta"><div><span>DESIGNER</span><strong>陈文静 / Chen Wenjing</strong></div><div><span>SCOPE</span><strong>{project.scope.join(' / ')}</strong></div><div><span>STATUS</span><strong>概念设计 / Concept design</strong></div></div></div><figure className="case-cover-image"><img src={project.hero} alt={`${project.title} 项目主视觉`} fetchPriority="high" /><figcaption>DESIGN IN CONTEXT / {project.number}</figcaption></figure></section>
      <div className="case-body"><aside className="case-sidebar"><p>THE DESIGN STORY</p><nav aria-label="案例章节导航">{project.sections.map((section,index) => <a key={section.id} href={`#/work/${project.slug}/${section.id}`} onClick={() => document.getElementById(section.id)?.scrollIntoView({ behavior: "instant" })} aria-current={active === section.id ? 'location' : undefined}><span>0{index+1}</span>{section.label}</a>)}</nav><a className="case-back" href="#work"><Arrow direction="left" /> 返回作品</a></aside><div className="case-chapters">{project.sections.map(section => <section className="case-section" id={section.id} key={section.id}><p className="case-eyebrow">{section.eyebrow}</p><h2>{section.title.split('\n').map(line => <span key={line}>{line}</span>)}</h2><p className="case-prose">{section.text}</p><ProcessBlocks section={section} />{section.journey && <ol className="case-journey">{section.journey.map(([phase,need,response],index)=><li key={phase}><span>0{index+1}</span><h3>{phase}</h3><p>{need}</p><small>{response}</small></li>)}</ol>}{section.comparison && <div className="case-comparison">{section.comparison.map(([type,existing,opportunity])=><div key={type}><h3>{type}</h3><p>{existing}</p><strong>{opportunity}</strong></div>)}</div>}{section.images && <div className={`case-gallery ${section.layout || ''}`}>{section.images.map(item=><Figure key={item.src} item={item}/>)}</div>}{section.cards && <div className="case-insights">{section.cards.map(([title,text],index)=><article key={title}><span>0{index+1}</span><h3>{title}</h3><p>{text}</p></article>)}</div>}{section.closingImage && <Figure item={section.closingImage}/ >}</section>)}</div></div>

      <a className="case-next" href={`#/work/${next.slug}`}><span>NEXT CASE STUDY / {next.number}</span><strong>{next.title}<Arrow className="next-arrow" /></strong><p>{next.chinese}</p></a>
    </main>
    <footer className="case-footer"><a href="#work"><Arrow direction="left" /> 所有作品</a><span>CHEN WENJING / INDUSTRIAL DESIGN</span><a href="mailto:427818148@qq.com">CONTACT <Arrow /></a></footer>
  </div>;
}



